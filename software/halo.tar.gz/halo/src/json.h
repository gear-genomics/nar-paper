#ifndef JSON_H
#define JSON_H

#include <boost/iostreams/filtering_streambuf.hpp>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/copy.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/device/file.hpp>

namespace halo
{
  

  template<typename TConfig, typename THeader, typename TSampleWC>
  inline void
  haloJsonOut(TConfig const& c, THeader const& hdr, TSampleWC const& sWC) {
    boost::iostreams::filtering_ostream rfile;
    rfile.push(boost::iostreams::gzip_compressor());
    rfile.push(boost::iostreams::file_sink(c.outfile.string().c_str(), std::ios_base::out | std::ios_base::binary));
    rfile << "{" << std::endl;
    rfile << "\"method\": \"" << c.method << "\"," << std::endl;
    rfile << "\"data\": [" << std::endl;
    for(uint32_t i = 0; i < c.sampleName.size(); ++i) {
      if (i > 0) rfile << "," << std::endl;
      rfile << "{" << std::endl;
      rfile << "\"sample\": \"" << c.sampleName[i] << "\"," << std::endl;
      rfile << "\"coverages\": [" << std::endl;
      for (int32_t refIndex = 0; refIndex<hdr[i]->n_targets; ++refIndex) {
	if (!sWC[0][refIndex].size()) continue;
	if (refIndex > 0) rfile << "," << std::endl;
	rfile << "{" << std::endl;
	rfile << "\"chromosome\": \"" << hdr[i]->target_name[refIndex] << "\"," << std::endl;
	rfile << "\"positions\": [" << std::endl;
	int32_t pos = 0;
	for (uint32_t k = 0; k < sWC[i][refIndex].size(); ++k) {
	  if (k > 0) rfile << ", ";
	  rfile << pos;
	  pos += c.window;
	}
	rfile << "]," << std::endl;
	rfile << "\"counts\": [" << std::endl;
	rfile << "{" << std::endl;
	rfile << "\"label\": \"" << (c.method == "HP_tagged" ? "HP1" : "Watson") << "\"," << std::endl;
	rfile << "\"values\": [" << std::endl;
	for (uint32_t k = 0; k < sWC[i][refIndex].size(); ++k) {
	  if (k > 0) rfile << ", ";
	  rfile << sWC[i][refIndex][k].first;
	}
	rfile << "]" << std::endl;
	rfile << "}," << std::endl;
	rfile << "{" <<	std::endl;
	rfile << "\"label\": \"" << (c.method == "HP_tagged" ? "HP2" : "Crick") << "\"," << std::endl;
	rfile << "\"values\": [" << std::endl;
	for (uint32_t k = 0; k < sWC[i][refIndex].size(); ++k) {
	  if (k > 0) rfile << ", ";
	  rfile << sWC[i][refIndex][k].second;
	}
	rfile << "]" << std::endl;
	rfile << "}" << std::endl;
	rfile << "]" << std::endl;
	rfile << "}";
      }
      rfile << "]" << std::endl;
      rfile << "}";
    }
    rfile << "]" << std::endl;
    rfile << std::endl;
    rfile << "}" << std::endl;
    rfile.pop();
  }
 
}

#endif
