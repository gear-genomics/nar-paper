# Supplemental Data

This file serves as landing page for the links to the supplemental data of the article:

--- in preparation ---

Each reference in the article is linked below to the respective parts in this section.

## References

### 2.3.2. Optical Calibrators

[The extensive test of optical calibrators.](optical_calibrators/README.md)

### 2.5.1. Primers

[The primer list.](untergasser/README.md#primer_test)

[The qPCR results of the primer test.](untergasser/README.md#primer_test)

### 2.4.2. DNA

[The DNA quantification results.](untergasser/README.md#dna_dilutions)

[The DNA dilution series.](untergasser/README.md#dPCR_quant)

### 2.4.4. PCR Efficiency Calculation Using DNA Dilutions

[The primer concentration results.](untergasser/README.md#primer_concentation)

### 2.4.5. The SYBR-Green Concentration Mystery

[Optical measurements of the dyes.](untergasser/README.md#sybr_mystery)

[Adding SYBR Green I to probe mixes.](untergasser/README.md#sybr_concentation)

[Creating an own qPCR mix.](untergasser/README.md#own_mix)

[Adding SYBR Green I to probe mixes and comparing it with commercial mixes.](untergasser/README.md#sybr_concentation)

### 2.4.7. Hydrolysis Probes

[The probe concentration has no big effect (plate 8).](untergasser/README.md#hydrolysis_probe)

### 2.5. Comparison with other qPCR algorithms

[The Vermeulen dataset.](vermeulen/README.md)

### 2.6. Hints on Getting Ncopy to Work in Your Lab

[The expected TD0 values.](untergasser/README.md#dna_dilutions)


## Data used to create the figures and tables

[Table 1 to Table 4 originate from the volume experiment.](untergasser/README.md#experiment_volume)

[Table 5 is based on the primer selection.](untergasser/README.md#primer_test)

[Table 6 is based on the primer test.](untergasser/README.md#primer_test)

[Figure 3 and Table 7 are based on the DNA dilution experiment.](untergasser/README.md#dPCR_quant)

[Table 8 is based on the primer dilution experiment.](untergasser/README.md#primer_concentation)

[Figure 5 compares PCR efficiencies from the DNA dilution experiment.](untergasser/README.md#dna_concentation)

[Table 9 combines data using the Roche.](untergasser/README.md#reporters) and [IDT probe mix (run B).](untergasser/README.md#eva_concentation)

[Table 10 originate from the probe experiment (plate 4).](untergasser/README.md#hydrolysis_probe)

[Table 11 is based on the reporter experiment.](untergasser/README.md#reporters)

[Table 12 was created using the Vermeulen dataset.](vermeulen/README.md)

