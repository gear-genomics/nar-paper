# apps-page

> Main page of GEAR, the genome analysis server.

## Build Setup

```bash
# clone
$ git clone https://github.com/gear-genomics/apps-page.git

# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build
$ npm run start

# for static hosting use the .output/public directory
$ npm run generate
```
